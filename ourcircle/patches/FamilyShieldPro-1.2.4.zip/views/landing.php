<?php
/** @var string $title */
/** @var string $site_home */
/** @var string $core_rule */
/** @var string $disclaimer */
/** @var array $plans */
/** @var array $flashes */
View::start($title, $site_home, 'index,follow', '/');
?>
<div class="wrap">
  <header class="site-header">
    <?= View::brand($site_home) ?>
    <nav class="nav">
      <a class="btn ghost" href="#contact">Contact</a>
      <a class="btn ghost" href="/login">Sign in</a>
      <a class="btn" href="/signup">Start a circle</a>
    </nav>
  </header>
  <?= View::flashesHtml($flashes) ?>
  <section class="hero">
    <div>
      <p class="core-rule"><?= Http::e($core_rule) ?></p>
      <h1>A family pause before you send a dime.</h1>
      <p class="lede">Family Shield Pro (OurCircle) is a trusted circle for the text, call, prize, or “urgent” payment that feels a little off. We are not an AI that stamps a request as safe. We help you stop, read the warning signs in plain language, and get someone you trust on the phone — then you decide.</p>
      <p>
        <a class="btn gold" href="/signup">Family yearly · $119.99</a>
        <a class="btn ghost" href="/signup">or $14.99/month</a>
      </p>
      <p class="disclaimer"><?= Http::e($disclaimer) ?></p>
    </div>
    <div class="hero-card">
      <a href="<?= Http::e($site_home) ?>" title="Family Shield Pro">
        <img src="/static/img/logo-lockup.png" alt="Family Shield Pro" />
      </a>
    </div>
  </section>
  <div class="panel story">
    <h2>Why we built this</h2>
    <p>We are invested in this because we have personally been the victim of so many scams over the years. They keep getting better and more believable. Fake banks. “Grandkid in trouble.” Prize emails. Refunds that are not refunds. You really have to be on your toes.</p>
    <p>So we built a place for a household to park the screenshot, look at the warning signs together, and call before anyone pays. Up to five people. A protected list of the real numbers for banks, doctors, and family. A “Please call me before I pay” button when it is urgent.</p>
  </div>
  <div class="too-good">
    <p class="rule-restated"><strong><?= Http::e($core_rule) ?></strong></p>
    <h2>If it sounds too good to be true, it usually is.</h2>
    <p class="really">Really! Really! Really!</p>
  </div>
  <h2>What you can do</h2>
  <div class="grid-3">
    <div class="panel step"><strong>1. Bring the request in</strong>Paste the email or text, upload a screenshot, or enter a phone number, website, offer, or payment ask.</div>
    <div class="panel step"><strong>2. Read the warning signs</strong>See why it might be a scam, whether a number or site resembles a known trick, and what to do next — never a “this is safe” stamp.</div>
    <div class="panel step"><strong>3. Involve your circle</strong>Ask a family member to look. Tap “Please call me before I pay” when it is urgent. Independently verify before money, crypto, gift cards, passwords, or account information moves.</div>
  </div>
  <div class="grid-2" style="margin-top:18px">
    <div class="panel">
      <h3>Protected trusted list</h3>
      <p>Save the real numbers for banks, doctors, insurers, utilities, and family. Checks compare incoming numbers and websites to that list — not to a stranger in the message.</p>
    </div>
    <div class="panel">
      <h3>If something already went wrong</h3>
      <p>Get calm instructions to report fraud, freeze cards, and tell the people who can actually stop a payment. Speed matters more than shame.</p>
    </div>
  </div>
  <h2 style="margin-top:36px">Family plans</h2>
  <div class="plans">
    <?php foreach ($plans as $p): ?>
    <div class="panel<?= !empty($p['featured']) ? ' featured' : '' ?>">
      <?php if (!empty($p['featured'])): ?><span class="plan-badge">Best for families</span><?php endif; ?>
      <h3><?= Http::e($p['name']) ?></h3>
      <p><strong><?= Http::e($p['price']) ?></strong></p>
      <p class="muted"><?= Http::e($p['detail']) ?></p>
    </div>
    <?php endforeach; ?>
  </div>
  <p>Churches, senior centers, and veterans groups: ask us about a shared license. Credit unions and insurers: per-member partnership pricing.</p>
  <section class="support-contact" id="contact">
    <h2>Customer service</h2>
    <p>Questions about your circle, billing, login, or this site? Email us. A person reads every message.</p>
    <p><a class="btn" href="mailto:CustomerService@FamilyShieldPro.com">CustomerService@FamilyShieldPro.com</a></p>
    <!--
      CUSTOMER SERVICE PHONE — commented out until a number is assigned.

      To bring it online (see SUPPORT.md):
      1. Uncomment the <p class="support-phone"> line below (remove this HTML comment wrapper).
      2. Replace +1XXXXXXXXXX and (XXX) XXX-XXXX with the live number.
      3. Optional: set SUPPORT_PHONE in the live .env (notes only; visitors see this markup).

      <p class="support-phone">Call us: <a href="tel:+1XXXXXXXXXX">(XXX) XXX-XXXX</a></p>
    -->
  </section>
  <footer class="footer">
    OurCircle is built for families — including parents, adult children, and grandparents — who want a second set of eyes. This application offers guidance, not a guarantee.
  </footer>
</div>
<?php View::end(); ?>
