<?php
/** @var array $rows */
View::appOpen(get_defined_vars());
?>
<p>Save the legitimate banks, doctors, insurers, utilities, and family numbers <em>before</em> a scare. When a message arrives, we compare it to this list — not to a number the stranger provided.</p>
<div class="grid-2">
  <div class="panel">
    <h2>Protected contacts</h2>
    <table class="table">
      <thead><tr><th>Kind</th><th>Name</th><th>Phone / site</th><th></th></tr></thead>
      <tbody>
        <?php if ($rows): ?>
          <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= Http::e($r['kind']) ?></td>
            <td><?= Http::e($r['name']) ?><div class="muted"><?= Http::e((string) $r['notes']) ?></div></td>
            <td><?= Http::e($r['phone'] ?: '—') ?><div class="muted"><?= Http::e((string) $r['website']) ?></div></td>
            <td>
              <form method="post" action="/trusted/<?= (int) $r['id'] ?>/delete" onsubmit="return confirm('Remove this contact?')">
                <button class="btn ghost" type="submit">Remove</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="4">None yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <form class="panel" method="post">
    <h2>Add a real contact</h2>
    <label>Kind</label>
    <select name="kind">
      <option value="bank">Bank</option>
      <option value="doctor">Doctor / clinic</option>
      <option value="insurer">Insurer</option>
      <option value="utility">Utility</option>
      <option value="family">Family</option>
      <option value="other">Other</option>
    </select>
    <label>Name</label>
    <input name="name" required placeholder="Credit union fraud line" />
    <label>Phone (from a statement or the back of a card)</label>
    <input name="phone" />
    <label>Website</label>
    <input name="website" placeholder="https://" />
    <label>Notes</label>
    <input name="notes" />
    <p><button class="btn wide" type="submit">Save on trusted list</button></p>
  </form>
</div>
<?php View::appClose(); ?>
